const express = require("express");
const app = express();
const http = require("http");
const { mongoose } = require("mongoose");
const { Socket } = require("socket.io");
const Room = require("./models/room");

const port=process.env.PORT || 3000;
var server =http.createServer(app);

var io=require("socket.io")(server);

app.use(express.json());

// database
const DB="mongodb+srv://namal:qazxnmlp@cluster0.jovzlek.mongodb.net/?retryWrites=true&w=majority";
mongoose.connect(DB).then(()=>{
    console.log("DB connection established");
}).catch(err => console.log(err) );
//database

io.on("connection",(socket)=>{
    console.log("IO connection established");
    socket.on("createRoom",async ({nickname})=>{
        try{
            let room =new Room();
            let player ={
                socketID:socket.id,
                nickname:nickname,
                playerType:"X",
            }
            room.players.push(player);
            room.turn=player;
            room=await room.save();
            const roomId=room._id.toString();
            socket.join(roomId);
            io.to(roomId).emit("createRoomSuccess",room);
            console.log("data sent");
        }catch(e){
            console.log(e);
        }
    });

        socket.on("joinRoom",async({nickname,roomId})=>{
            try{
                if(!roomId.match(/^[0-9a-fA-F]{24}$/)){
                    socket.emit("errorOccurred","Please enter a valid room ID");
                    return;
                }
                let room =await Room.findById(roomId);
                if(room.isJoin){
                    // room.isJoin = false;
                    let player = {
                        nickname,
                        socketID:socket.id,
                        playerType:'O',
                    }
                    socket.join(roomId);
                    room.players.push(player);
                    room = await room.save();
                    io.to(roomId).emit("joinRoomSuccess",room);
                    io.to(roomId).emit("testListener",room);

                }else{
                    socket.emit("errorOccurred","Game is in progress"); 
                }
            }catch(e){
                console.log(e);
            }


    });
});



app.get("/", function(req, res) {
    res.send("no"+process.env.PORT);
});

server.listen(port, "0.0.0.0", () => {
    console.log("udaya " +port);
});